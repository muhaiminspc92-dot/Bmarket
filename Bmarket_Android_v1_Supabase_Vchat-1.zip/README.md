# Bmarket Android v1.0 (berbasis proyek Vchat)

## Yang sudah disiapkan
- Login dan registrasi Supabase tetap memakai project Vchat yang sama.
- Beranda marketplace dengan pencarian dan kategori.
- Daftar produk dari database Supabase.
- Form penjual untuk menerbitkan produk dengan URL gambar opsional.
- Pesanan demo dan daftar pesanan pembeli.
- Penjual dapat mengaktifkan/menonaktifkan produk.
- Profil dan logout.
- Tabel dan kebijakan RLS marketplace ditambahkan tanpa menghapus `profiles` dan `messages`.

## Langkah pemasangan database
1. Buka Supabase project Vchat yang sudah dipakai aplikasi.
2. Buka SQL Editor.
3. Buka file `supabase/bmarket_schema.sql` dari ZIP ini.
4. Salin seluruh SQL dan jalankan sekali.
5. Jangan jalankan ulang schema lama yang menghapus tabel. File baru ini hanya menambahkan tabel marketplace.

## Menjalankan Android
Pastikan Flutter SDK tersedia, lalu:
```bash
flutter pub get
flutter run
```
Untuk APK:
```bash
flutter build apk --release
```
APK berada di `build/app/outputs/flutter-apk/app-release.apk`.

## Catatan penting
- URL dan publishable key Supabase dipertahankan dari proyek Vchat yang diberikan.
- Jangan pernah memasukkan `service_role` key ke aplikasi.
- Checkout saat ini hanya membuat catatan pesanan demo. Tidak ada pembayaran sungguhan.
- Belum ada upload foto langsung, alamat pengiriman, ongkir, pembayaran, chat pembeli-penjual yang terhubung dari produk, dashboard admin, atau pengurangan stok atomik.
- Sebelum transaksi sungguhan, checkout harus dipindahkan ke fungsi database/server dengan validasi harga dan stok, serta integrasi pembayaran.
- Untuk rilis produksi perlu pengujian, kebijakan RLS tambahan, moderasi, pelaporan, pagination, dan perlindungan spam.
