import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://lldbmljqgfaxsgelkdam.supabase.co';
const supabaseAnonKey = 'sb_publishable_K6e8FZBchvSQV08N1RFxTQ_N9GoPdX1';
final supabase = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const BmarketApp());
}

class BmarketApp extends StatelessWidget {
  const BmarketApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Bmarket', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087E72)), useMaterial3: true),
    home: supabase.auth.currentSession == null ? const AuthPage() : const MainPage(),
  );
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final email=TextEditingController(), password=TextEditingController(), username=TextEditingController();
  bool login=true, busy=false; String? error;
  Future<void> submit() async {
    setState(() {busy=true; error=null;});
    try {
      if(login) {
        await supabase.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      } else {
        await supabase.auth.signUp(email: email.text.trim(), password: password.text,
          data: {'username': username.text.trim().isEmpty ? email.text.split('@').first : username.text.trim()});
      }
      if(!mounted)return;
      if(supabase.auth.currentSession!=null) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainPage()));
      } else { setState(()=>error='Periksa email untuk konfirmasi akun, lalu masuk.'); }
    } on AuthException catch(e) {setState(()=>error=e.message);}
      catch(e){setState(()=>error=e.toString());}
    finally {if(mounted)setState(()=>busy=false);}
  }
  @override void dispose(){email.dispose();password.dispose();username.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(body:Center(child:SingleChildScrollView(
    padding:const EdgeInsets.all(24), child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:420),child:Column(
      crossAxisAlignment:CrossAxisAlignment.stretch, children:[
        const Icon(Icons.storefront_rounded,size:68,color:Color(0xFF087E72)),
        const Text('Bmarket',textAlign:TextAlign.center,style:TextStyle(fontSize:32,fontWeight:FontWeight.bold)),
        const Text('Belanja mudah, jualan lebih luas',textAlign:TextAlign.center),
        const SizedBox(height:28),
        if(!login) ...[TextField(controller:username,decoration:const InputDecoration(labelText:'Nama pengguna',border:OutlineInputBorder())),const SizedBox(height:12)],
        TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())),
        if(error!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.red))),
        const SizedBox(height:18),
        FilledButton(onPressed:busy?null:submit,child:Text(busy?'Memproses...':login?'Masuk':'Daftar')),
        TextButton(onPressed:busy?null:()=>setState(()=>login=!login),child:Text(login?'Belum punya akun? Daftar':'Sudah punya akun? Masuk'))
      ])))));
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override State<MainPage> createState()=>_MainPageState();
}
class _MainPageState extends State<MainPage> {
  int tab=0; String search=''; String category='Semua';
  final categories=['Semua','Elektronik','Fashion','Rumah Tangga','Kecantikan','Makanan','Olahraga','Otomotif','Lainnya'];
  Future<List<Map<String,dynamic>>> products() async {
    var q=supabase.from('products').select().eq('is_active',true);
    if(category!='Semua') q=q.eq('category',category);
    if(search.trim().isNotEmpty) q=q.ilike('name','%${search.trim()}%');
    final data=await q.order('created_at',ascending:false).limit(100);
    return List<Map<String,dynamic>>.from(data);
  }
  Future<void> buy(Map<String,dynamic> p) async {
    final qty=TextEditingController(text:'1');
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
      title:const Text('Buat pesanan'),content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(p['name']??''),Text('Harga: ${rupiah(p['price'])}'),
        TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Jumlah'))
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Pesan'))]));
    if(ok!=true)return;
    final n=int.tryParse(qty.text)??0; qty.dispose();
    if(n<1 || n>(p['stock'] as int? ?? 0)){if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Jumlah tidak valid atau stok tidak cukup')));return;}
    try {
      final user=supabase.auth.currentUser!.id;
      final order=await supabase.from('orders').insert({'buyer_id':user,'total_amount':(p['price'] as num)*n,'status':'Menunggu konfirmasi'}).select('id').single();
      await supabase.from('order_items').insert({'order_id':order['id'],'product_id':p['id'],'seller_id':p['seller_id'],'quantity':n,'unit_price':p['price']});
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Pesanan berhasil dibuat. Pembayaran belum diproses.')));
      setState((){});
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Pesanan gagal: $e')));}
  }
  Future<void> addProduct() async {
    final name=TextEditingController(), desc=TextEditingController(), price=TextEditingController(), stock=TextEditingController(text:'1'), image=TextEditingController();
    String cat='Elektronik';
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,refresh)=>AlertDialog(
      title:const Text('Jual produk'),content:SizedBox(width:420,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:name,decoration:const InputDecoration(labelText:'Nama produk')),
        TextField(controller:desc,maxLines:2,decoration:const InputDecoration(labelText:'Deskripsi')),
        TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Harga (Rp)')),
        TextField(controller:stock,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stok')),
        TextField(controller:image,decoration:const InputDecoration(labelText:'URL gambar (opsional)')),
        DropdownButtonFormField<String>(value:cat,decoration:const InputDecoration(labelText:'Kategori'),items:categories.where((e)=>e!='Semua').map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>refresh(()=>cat=v??cat))
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Terbitkan'))])));
    if(ok==true) {
      try {
        await supabase.from('products').insert({'seller_id':supabase.auth.currentUser!.id,'name':name.text.trim(),'description':desc.text.trim(),'price':int.parse(price.text),'stock':int.parse(stock.text),'image_url':image.text.trim().isEmpty?null:image.text.trim(),'category':cat});
        if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Produk berhasil diterbitkan')));setState((){});}
      }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal menerbitkan produk: $e')));}
    }
    name.dispose();desc.dispose();price.dispose();stock.dispose();image.dispose();
  }
  Future<void> logout() async {await supabase.auth.signOut();if(mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const AuthPage()),(_)=>false);}
  @override Widget build(BuildContext context) {
    final pages=[
      _home(),
      _myProducts(),
      _orders(),
      _profile()
    ];
    return Scaffold(appBar:AppBar(title:const Text('Bmarket',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:()=>setState((){}),icon:const Icon(Icons.refresh)),]),
      body:pages[tab],
      floatingActionButton:tab==1?FloatingActionButton.extended(onPressed:addProduct,icon:const Icon(Icons.add),label:const Text('Jual')):null,
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Beranda'),
        NavigationDestination(icon:Icon(Icons.storefront_outlined),selectedIcon:Icon(Icons.storefront),label:'Jualan'),
        NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'Pesanan'),
        NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Akun')
      ]));
  }
  Widget _home()=>Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(16,12,16,8),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari produk di Bmarket',border:OutlineInputBorder(),isDense:true),onChanged:(v)=>setState(()=>search=v))),
    SizedBox(height:48,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:12),children:categories.map((c)=>Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c)))).toList())),
    Expanded(child:FutureBuilder<List<Map<String,dynamic>>>(future:products(),builder:(c,s){
      if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
      if(s.hasError)return Center(child:Text('Gagal memuat produk: ${s.error}'));
      final items=s.data??[];
      if(items.isEmpty)return const Center(child:Text('Belum ada produk. Jadilah penjual pertama di Bmarket!'));
      return GridView.builder(padding:const EdgeInsets.all(12),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.68,crossAxisSpacing:12,mainAxisSpacing:12),itemCount:items.length,itemBuilder:(c,i)=>ProductCard(product:items[i],onBuy:()=>buy(items[i])));
    }))
  ]);
  Widget _myProducts()=>FutureBuilder<List<Map<String,dynamic>>>(future:supabase.from('products').select().eq('seller_id',supabase.auth.currentUser!.id).order('created_at',ascending:false).then((d)=>List<Map<String,dynamic>>.from(d)),builder:(c,s){
    if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
    if(s.hasError)return Center(child:Text('Gagal memuat produk: ${s.error}'));
    final list=s.data??[];if(list.isEmpty)return const Center(child:Text('Anda belum menjual produk. Tekan tombol Jual.'));
    return ListView(children:list.map((p)=>ListTile(leading:const CircleAvatar(child:Icon(Icons.inventory_2)),title:Text(p['name']??''),subtitle:Text('${rupiah(p['price'])} • Stok ${p['stock']}'),trailing:Switch(value:p['is_active']==true,onChanged:(v)async{await supabase.from('products').update({'is_active':v}).eq('id',p['id']);setState((){});}))).toList());
  });
  Widget _orders()=>FutureBuilder<List<Map<String,dynamic>>>(future:supabase.from('orders').select().eq('buyer_id',supabase.auth.currentUser!.id).order('created_at',ascending:false).then((d)=>List<Map<String,dynamic>>.from(d)),builder:(c,s){
    if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
    if(s.hasError)return Center(child:Text('Gagal memuat pesanan: ${s.error}'));
    final list=s.data??[];if(list.isEmpty)return const Center(child:Text('Belum ada pesanan.'));
    return ListView(children:list.map((o)=>ListTile(leading:const Icon(Icons.receipt_long),title:Text('Pesanan #${o['id']}'),subtitle:Text('${rupiah(o['total_amount'])} • ${o['status']}'))).toList());
  });
  Widget _profile()=>Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    const CircleAvatar(radius:36,child:Icon(Icons.person,size:40)),
    const SizedBox(height:12),Text(supabase.auth.currentUser?.email??'',style:const TextStyle(fontWeight:FontWeight.bold)),
    const SizedBox(height:8),const Text('Bmarket • Marketplace semua kategori'),
    const SizedBox(height:20),OutlinedButton.icon(onPressed:logout,icon:const Icon(Icons.logout),label:const Text('Keluar'))
  ]));
}

class ProductCard extends StatelessWidget {
  final Map<String,dynamic> product; final VoidCallback onBuy;
  const ProductCard({super.key,required this.product,required this.onBuy});
  @override Widget build(BuildContext context){
    final url=product['image_url'] as String?;
    return Card(clipBehavior:Clip.antiAlias,child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Expanded(child:url!=null&&url.startsWith('http')?Image.network(url,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.image_not_supported,size:52)):const ColoredBox(color:Color(0xFFEAF2F0),child:Icon(Icons.shopping_bag_outlined,size:52))),
      Padding(padding:const EdgeInsets.fromLTRB(10,8,10,0),child:Text(product['name']??'Produk',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w600))),
      Padding(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),child:Text(rupiah(product['price']),style:const TextStyle(color:Color(0xFF087E72),fontWeight:FontWeight.bold))),
      Padding(padding:const EdgeInsets.fromLTRB(8,0,8,8),child:FilledButton(onPressed:(product['stock']??0)>0?onBuy:null,child:const Text('Beli')))
    ]));
  }
}
String rupiah(dynamic v){final n=(v as num?)?.toInt()??0;final s=n.toString();final b=StringBuffer();for(var i=0;i<s.length;i++){if(i>0&&(s.length-i)%3==0)b.write('.');b.write(s[i]);}return 'Rp${b.toString()}';}
